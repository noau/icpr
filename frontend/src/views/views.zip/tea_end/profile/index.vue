<template>
  <div>
    <h1>个人中心页面</h1>
    <p>这里是个人中心页面的内容。</p>
  </div>
</template>

<script>
export default {
//   name: 'ProfileView',
};
</script>